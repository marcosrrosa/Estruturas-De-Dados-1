#include <stdio.h> 

float potencia(int base, int exp){
    int i;
    float resultado = 1;
    int qtditeracoes = (exp >= 0)? exp : exp*-1;

   /* if (exp >= 0){
        qtditeracoes = exp;
    }
    else {
        qtditeracoes--;
    }
    */

    for(i = 0; i < qtditeracoes; i++){
        resultado *= base;
    }
    return (exp >= 0? resultado: 1/resultado);
}

int main (){

    //entrada
    int base = 2;
    int exp = -2;

    //processamento
    float resultado = potencia(base, exp);

    //saida
    printf("Resultado: %f\n", resultado);
}