#include <stdio.h>

int inverso(int num){
    int inverte = 0;
    int res = 0;

    while(res != 0){
        res = num % 10;
        inverte = (inverte * 10) + res;
        num = num/10;
    }
    return inverte;
}

int main (){
    
    printf("1245678: %d\n", inverso(1245678));
}

