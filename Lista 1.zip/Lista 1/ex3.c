#include <stdio.h>

char conceito(float nota){

    char conceito;

    if (nota < 0 || nota > 10){
        return 'X';
    }
      
    
    if (nota >= 9.0){
        conceito = 'A';
    }
    else if (nota >= 7.0){
        conceito = 'B';
    }
    else if (nota >= 6.0){
        conceito = 'C';
    }
    else{
        conceito = 'I';
    }

    return conceito;
}

int main()
{
    printf("10.0: %c \n", conceito(6.5));
    
}