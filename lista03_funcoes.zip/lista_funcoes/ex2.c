#include <stdio.h>

int inverte(int num){
    int inverso = 0;
    int digito = 0;

    while(num != 0){
        digito = num % 10;
        inverso = (inverso * 10) + digito;
        num = num/10;
    }
    return inverso;
}

int inverte2(int num, int *inverso){
    int digito = 0;
    int inv = 0;

    while(num > 0){
        digito = num % 10;
        inv = (inv * 10) + digito;
        num = num/10;
    }
    *inverso = inv;
}

void main (){

    int inverso;
    int inv;
    printf("124: %d\n", inverte(124));

    inverte2(158, &inverso);
    printf("158: %d\n", inverso);
}


