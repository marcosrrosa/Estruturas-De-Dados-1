#include <stdio.h>

char conceito(float nota){

    char conceito;

    if (nota < 0 || nota > 10){
        return 'X';
    }
      
    
    if (nota >= 9.0){
        conceito = 'A';
    }
    else if (nota >= 7.0){
        conceito = 'B';
    }
    else if (nota >= 6.0){
        conceito = 'C';
    }
    else{
        conceito = 'I';
    }

    return conceito;
}

char conceito2(float nota, char *conc){
    char conceito;

    if (nota < 0 || nota > 10){
        *conc = 'x';
    }
      
    else{
        if (nota >= 9.0){
            conceito = 'A';
        }
        else if (nota >= 7.0){
            conceito = 'B';
        }
        else if (nota >= 6.0){
            conceito = 'C';
        }
        else{
            conceito = 'I';
        }
        *conc = conceito;
    }

     
}



int main()
{
    char conc;

    printf("8.0: %c \n", conceito(8.0));
    
    conceito2(1.5, &conc);
    printf("1.5: %c \n", conc);


}