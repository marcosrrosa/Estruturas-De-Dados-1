#include <stdio.h>

int potencia1(int base, int exp){
    
    float resultado = 1;

    int qtdite = (exp >= 0)? exp : exp*-1;

    for(int i = 0; i < qtdite; i++){
        resultado *= base;
    }
    
    return (exp >= 0? resultado: 1/resultado);
}

void potencia2(int base, int exp, int *resultado){

    int qtdite = (exp >= 0)? exp : exp*-1;

    for(int i = 0; i < qtdite; i++){
        *resultado *= base;
    }

    (exp >= 0? *resultado: 1 / *resultado);
}

int main(){
    int base = 2;
    int exp = 3;

    float resultado;
    resultado = potencia1(base, exp);
    printf("2 ^ 2 = %.2f\n", resultado);

    printf("2 ^ 2 = %.2f\n", &resultado);
}
