#include <stdio.h>

void printvetor(int* v, int tam){
	int valor = 1;
	for(int i = 0; i< tam; i++){
		*(v + i) = valor
		valor++;
		printf("valor :%d na posição: %d", valor, i);
	}	
}

int main(){
	int v[6];

	printfvetor(v1, 4);


}