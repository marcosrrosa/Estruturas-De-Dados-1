#include <stdio.h>

int maiorvet(int* v, int tam){
	int *maior;
	for(int i = 0; i < tam; i++){
		if(*(v+i) > *maior){
			*maior = *(v+i);
		}
	}
	return maior;
}

int main(){
	int v1[9];
	int maior1;
	maior1 = *maior;
	printf("maior: %d", maior1);

}