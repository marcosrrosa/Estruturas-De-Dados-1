#include <stdio.h>

//Escreva uma fun��o que crie um clone de um determinado vetor

void vetor_clone(int *v, int tam, int *copia){
     for(int i=0; i<tam; i++)
        copia[i]=v[i];
}

int main(){
    int copia[tam];
    vetor_clone(v, tam, &copia);

    for(int i=0; i<tam; i++){
        printf("%d ",copia[i]);
    }
}
