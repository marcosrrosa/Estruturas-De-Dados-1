#include <stdio.h>

//Escreva uma fun��o que dado um vetor, dobre o valor de cada elemento.

void vetor_dobra(int *v1, int tam){
    for(int i = 0; i < tam; i++){
        v1[i] = v1[i]*2;
        printf("%d\n",v1[i]);
    }

}

int main(){
    int v1[5] = {10, 20, 30, 40, 50};
    vetor_dobra(v1, 5);

}
