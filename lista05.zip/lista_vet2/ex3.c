#include <stdio.h>

//Escreva uma fun��o que dado um vetor, adicione 1 ao valor de cada elemento.

void add1(int *v, int tam){
    for(int i = 0; i < tam; i++){
        v[i] = v[i]+1;
        printf("%d\n",v[i]);
    }

}


int main(){
    int v[5] = {10,20,30,40,50};
    add1(v, 5);

}
