#include <stdio.h>
#include <stdlib.h>

//Escreva uma função que crie um vetor preenchido com valores aleatórios.

void vetor_aleatorio(int *v, int tam){
     for(int i=0; i<tam; i++)
        v[i]=rand()%tam;
        for(int i=0; i<tam; i++)
        printf("%d ",v[i]);
}




int main(){
  int tam = 5;
 int v[] = {1,1,1,1,2};

   vetor_aleatorio(v, tam);
   printf("\n");

}
